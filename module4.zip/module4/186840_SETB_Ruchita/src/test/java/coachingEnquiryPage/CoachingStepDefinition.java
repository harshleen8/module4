package coachingEnquiryPage;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.CoachingBeanPageFactory;

public class CoachingStepDefinition {
	
	private WebDriver driver;
	private CoachingBeanPageFactory coachingPageFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\hsadhnan\\chromedriver/chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	
	@Given("^User is on 'Enquiry form' page$")
	public void user_is_on_Enquiry_form_page() throws Throwable {
		driver.get("C:\\Users\\hsadhnan\\Desktop\\186840_SETB_Ruchita\\Coaching_Class_Enquiry.html");
		coachingPageFactory=new CoachingBeanPageFactory(driver);
	    
	}


	
	@Then("^'Verifying the title of the page'$")
	public void verifying_the_title_of_the_page() throws Throwable {
		String expectedMessage="Online Coaching Class Enquiry Form";
	String actualMessage=driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@Then("^'Verifying the text on page'$")
	public void verifying_the_text_on_page() throws Throwable {
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Shree Coaching Classes"));
		driver.close();
	}

	@When("^user enters invalid firstname$")
	public void user_enters_invalid_firstname() throws Throwable {
	    
		coachingPageFactory.setFirstName("");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^display message 'First Name must be filled out'$")
	public void display_message_First_Name_must_be_filled_out() throws Throwable {
		String expectedmessage="First Name must be filled out";
		String actualmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}

	@When("^user enters invalid lastname$")
	public void user_enters_invalid_lastname() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^display message 'Last Name must be filled out'$")
	public void display_message_Last_Name_must_be_filled_out() throws Throwable {
		String expectedmessage="Last Name must be filled out";
		String actualmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	    
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("");
		coachingPageFactory.setSubmitButton();
	}
	@Then("^displays message 'Email must be filled out'$")
	public void displays_message_Email_must_be_filled_out() throws Throwable {
		String expectedmessage="Email must be filled out";
		String actualmessage=driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}
	
	@When("^user enters invalid Mobile Number$")
	public void user_enters_invalid_Mobile_Number() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
		coachingPageFactory.setMobileNumber("");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'Mobile must be filled out'$")
	public void displays_Mobile_must_be_filled_out() throws Throwable {
		String expectedMessage="Mobile must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}
	
	@When("^user enters alphabetic Mobile Number$")
	public void user_enters_alphabetic_Mobile_Number() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
		coachingPageFactory.setMobileNumber("abcde");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'Enter numeric value'$")
	public void displays_Enter_numeric_value() throws Throwable {
		String expectedMessage="Enter numeric value";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}

	@When("^user enters Invalid Mobile Number$")
	public void user_enters_Invalid_Mobile_Number() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
		coachingPageFactory.setMobileNumber("34566");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'Enter (\\d+) digit Mobile number'$")
	public void displays_Enter_digit_Mobile_number(int arg1) throws Throwable {
			String expectedMessage="Enter 10 digit Mobile number";
			String actualMessage=driver.switchTo().alert().getText();
			Assert.assertEquals(expectedMessage, actualMessage);
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
		
			driver.close();
	}
	@When("^user enters wrong Mobile Number$")
	public void user_enters_wrong_Mobile_Number() throws Throwable {
//     	coachingPageFactory.setFirstName("Ruchita");
//		coachingPageFactory.setLastName("Lingampalli");
//		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
//		coachingPageFactory.setMobileNumber("1234567891");
//		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'it should start with nine'$")
	public void displays_it_should_start_with_nine() throws Throwable {
//		String expectedMessage="it should start with nine";
//		String actualMessage=driver.switchTo().alert().getText();
//		Assert.assertEquals(expectedMessage, actualMessage);
//		driver.switchTo().alert().accept();
//		driver.close();
	}
	@When("^user clicks 'Submit' button$")
	public void user_clicks_Submit_button() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
		coachingPageFactory.setMobileNumber("9849346278");
		coachingPageFactory.setTutionType("Spoken English");
		coachingPageFactory.setCity("Pune");
		coachingPageFactory.setLearningMode("Class room training");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'Enquiry details must be filled out'$")
	public void displays_Enquiry_details_must_be_filled_out() throws Throwable {
		String expectedMessage="Enquiry details must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}
	@When("^user clicks 'Submit your request' button$")
	public void user_clicks_Submit_your_request_button() throws Throwable {
		coachingPageFactory.setFirstName("Ruchita");
		coachingPageFactory.setLastName("Lingampalli");
		coachingPageFactory.setEmail("ruchitalingampalli@gmail.com");
		coachingPageFactory.setMobileNumber("9849346278");
		coachingPageFactory.setTutionType("Spoken English");
		coachingPageFactory.setCity("Pune");
		coachingPageFactory.setLearningMode("Class room training");
		coachingPageFactory.setEnquiryTextBox("Information");
		coachingPageFactory.setSubmitButton();
	}

	@Then("^displays 'Thank you for submitting the online coaching Class Enquiry'$")
	public void displays_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
		String expectedMessage="Thank you for submitting the online coaching Class Enquiry";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		driver.close();
	}
	
	@When("^user clicks 'Alert box message'$")
	public void user_clicks_Alert_box_message() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Then("^displays 'Our Counselor will contact you soon'$")
	public void displays_Our_Counselor_will_contact_you_soon() throws Throwable {
		String bodyText=driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Our Counselor will contact you soon."));
		Thread.sleep(2000);
		driver.close();
	}

	

}
